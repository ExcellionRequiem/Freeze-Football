package com.freezefootball.frzftball;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrzftballApplicationTests {

	@Test
	void contextLoads() {
	}

}
